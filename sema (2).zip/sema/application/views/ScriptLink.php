  <script src="<?php echo base_url(); ?>assests/js/jquery.min.js" rel="stylesheet"></script>
       
<script src="<?php echo base_url(); ?>assests/js/bootstrap.min.js" rel="stylesheet"></script>
<script src="<?php echo base_url(); ?>assests/js/common.js" rel="stylesheet"></script>
