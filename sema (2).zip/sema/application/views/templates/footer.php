<footer>
    <script src="<?php echo base_url(); ?>assests/js/jquery.min.js" rel="stylesheet"></script>
    <script src="<?php echo base_url(); ?>assests/js/jquery.multiselect.js" rel="stylesheet"></script>
    <link href="<?php echo base_url(); ?>assests/css/jquery.multiselect.css" rel="stylesheet">
</footer>