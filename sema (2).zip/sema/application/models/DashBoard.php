<?php 
/***
    Model : SemaDataDashBoard
    CreatedBy : Ankita
    CreatedDate : 27-09-2018
***/

if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class DashBoard extends CI_Model{

   function __construct(){
      parent::__construct();
    }    
}